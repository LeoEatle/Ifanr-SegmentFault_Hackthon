App({
  onLaunch: function () {
    console.log('App Launch')
  },
  onShow: function () {
    console.log('App Show')
  },
  onHide: function () {
    console.log('App Hide')
  }
})

Page({
  data:{
    src: 'please.jpg',
    disabled: false,
    if_limited: false,
    wx_name: "",
    activity_name: "",
    activity_description: ""

    // text:"这是一个页面"
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    console.log("onload")
  },
  onReady:function(){
    // 页面渲染
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭

  },
  switchchange: function(e){
    console.log(e);
    this.setData({
      
    })
  },
  postTap: function(){
    console.log("postTap");
    for (i in document){
      console.log(i);
    }
  },


})